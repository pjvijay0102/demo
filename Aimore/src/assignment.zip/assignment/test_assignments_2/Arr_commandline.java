package test_assignments_2;

public class Arr_commandline {

	public static void main(String[] args) {
		
	int []a={1,2,3,4,5};
	
	int count=0;
		for(int i=0;i<a.length;i++){
			count++;
		}
		System.out.println(count);

	}
	//	System.out.println(a.length); -----inbuild method
//	}
//	
}
