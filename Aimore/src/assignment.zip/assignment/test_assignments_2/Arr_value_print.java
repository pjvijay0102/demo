package test_assignments_2;

public class Arr_value_print {

	public static void main(String[] args) {
		
		String []a={"vijay","vinoth","raj"};
		
		for(String i :a){
			System.out.println(i);
		}
	}

}
