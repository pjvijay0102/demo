package test_assignments_2;

public class Passitive_negative_using_command {

	public static void main(String[] args) {
		int a=Integer.parseInt(args[0]);
		if(a<=0)
			System.out.println(a+"is Negative Number");
		else
			System.out.println(a+"is a possitive Number");
	}

	

}
