package test_assignments_looping;

public class Largevalue {
	
	public static void main(String[] args) {
		int a=Integer.parseInt(args[0]);
		for(int i=a;i>=0;i--){
			System.out.println(i);
		}
	}
}
